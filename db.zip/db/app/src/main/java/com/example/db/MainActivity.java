package com.example.db;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.*;
import android.database.*;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button insert, delete, select;
    private EditText name, email,pass, searchQuery;
    private SQLiteDatabase sql;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        email = findViewById(R.id.email);
        name = findViewById(R.id.name);
        pass = findViewById(R.id.pass);
        searchQuery = findViewById(R.id.searchQuery);
        insert = findViewById(R.id.insert);
        delete = findViewById(R.id.delete);
        select = findViewById(R.id.select);

        sql = openOrCreateDatabase("bc", Context.MODE_PRIVATE, null);
        sql.execSQL("CREATE TABLE IF NOT EXISTS customer(ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,email VARCHAR , n VARCHAR, p VARCHAR)");

        insert.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            String insertQ = "INSERT INTO customer(email,n,p) VALUES('" + email.getText().toString() + "','" + name.getText().toString() + "','" + pass.getText().toString() + "')";
                            sql.execSQL(insertQ);
                            Toast.makeText(getApplicationContext(), "inserted", Toast.LENGTH_LONG).show();
                        }
                        catch (Exception e){
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    String text = searchQuery.getText().toString();

                    String query = "SELECT * FROM customer WHERE email ='"+searchQuery.getText().toString()+"'";
                    Cursor c = sql.rawQuery(query, null);
                    Log.i("BC", "BC");
                    while (c.moveToNext()) {
                        Log.i("RESULT", c.getString(2));
                        Toast.makeText(getApplicationContext(), c.getString(2), Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();

                }
            }
        });

    }
}