package com.example.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReciever extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle b = intent.getExtras();
        Object[] sms = (Object[]) b.get("pdus");
        for(Object obj: sms){
            SmsMessage message = SmsMessage.createFromPdu((byte[]) obj);
            String mob = message.getDisplayOriginatingAddress();
            String text = message.getMessageBody();

            Toast.makeText(context, mob + " " + text, Toast.LENGTH_LONG).show();
        }
    }
}
