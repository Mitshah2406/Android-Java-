package com.example.sms;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button sub;
    private EditText num;
    private EditText msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sub = findViewById(R.id.submit);
        num = findViewById(R.id.num);
        msg= findViewById(R.id.msg);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(num.getText().toString(), null, msg.getText().toString(), null, null);
                Toast.makeText(getApplicationContext(), "Sent", Toast.LENGTH_LONG).show();
            }
        });
    }
}