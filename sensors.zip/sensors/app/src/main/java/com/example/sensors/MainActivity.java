package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
        private ListView lw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lw = (ListView) findViewById(R.id.list);

        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);

        List<String> sensorList = new ArrayList<>();

        for(int i =0; i<sensors.size();i++){
            sensorList.add(sensors.get(i).getName());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.mylist, sensorList);

        lw.setAdapter(adapter);
    }
}